<?php
/*

PBSWeb-Lite: A Simple Web-based Interface to PBS

Copyright (C) 2003, 2004 Yuan-Chung Cheng

PBSWeb-Lite is based on the PBSWeb code written by Paul Lu et al.
See History for more detailes.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
?>
/*

PBSWeb: A Web-based Interface to PBS
Copyright (C) 2000, 2001  Paul Lu

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

.......................
Please leave this copyright notice intact.
See http://www.gnu.org/copyleft/gpl.html for further details

Contact information:
	Paul Lu
	Assistant Professor
	Dept. of Computing Science
	Athabasca Hall
	University of Alberta
	Edmonton, Alberta, T6G 2E8
	Canada

	E-mail:         paullu@cs.ualberta.ca
	Web:            http://www.cs.ualberta.ca/~paullu/

Other contributors to PBSWeb (as of July 2001)
	George Ma, Victor Salamon, Christopher Pinchak, Yaling Pei,
	Jonathan Schaeffer, Duane Szafron
*/
